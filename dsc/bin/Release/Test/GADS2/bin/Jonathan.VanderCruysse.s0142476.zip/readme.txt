Portfolio Opdracht 1 
Jonathan Van der Cruysse - Informatica Ba 1 - s0142476

ProjectDataTypes.py bevat de code voor de implementatie van de Stack en Binary Tree, hun vereisten en gebruikers.

Een aantal klassen in ProjectDataTypes.py bevatten zelf geen implementatie, maar "raisen" een NotImplementedError indien een subclass een methode niet implementeert.
Dit is onderdeel van het ontwerp: het laat toe "isinstance(..., ...)" te gebruiken, en maakt debugging gemakkelijk.
Deze klassen komen precies overeen met de functionaliteit gedefinieerd in het ontwerp voor het hele systeem.

ProjectTest.py is de test file, die uitvoerbaar is vanuit de command line.
Als de tests geslaagd zijn, zou "All tests successful" op de console moeten verschijnen.