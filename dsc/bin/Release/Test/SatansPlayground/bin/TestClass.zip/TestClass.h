
class TestClass
{

private:
	int Value = 0;

public:
	int GetValue() const;

	long long Pow(const int Exponent) const;

	TestClass(const int Value);

};