#include "TestClass.h"

int TestClass::GetValue() const
{
	return this->Value;
}

long long TestClass::Pow(const int Exponent) const
{
	int i;
	int result;
	result = 1;
	i = 0;
	while (i < Exponent)
	{
		result = result * this->Value;
		i = i + 1;
	}
	return (long long)result;
}

TestClass::TestClass(const int Value)
{
	this->Value = Value;
}